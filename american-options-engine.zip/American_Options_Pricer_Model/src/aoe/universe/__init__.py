BLUE_CHIPS = [
    # Mega-caps
    "AAPL", "MSFT", "NVDA", "AMZN", "META", "GOOG", "AVGO", "CRM",
    # Staples / Healthcare
    "JNJ", "PG", "PEP", "MRK", "UNH",
    # Financials / Industrials
    "JPM", "GS", "CAT", "BA",
    # Energy / Materials
    "XOM", "CVX",
    # ETFs
    "SPY", "QQQ", "IWM", "DIA", "XLK", "XLF", "XLE",
]
