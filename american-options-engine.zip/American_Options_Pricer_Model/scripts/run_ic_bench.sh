#!/usr/bin/env bash
set -euo pipefail

# Smoke: SPY only
python -m scripts.optimize_ic \
  --start 2021-01-01 --end 2022-12-31 \
  --tickers SPY \
  --dtes 14 21 \
  --wings 2 5 \
  --ptails 0.10 0.20 \
  --edges -2.5 0 2.5 \
  --train_years 1 --test_months 3 \
  --outroot data/opt_ic_smoke

# Mid: SPY + QQQ
python -m scripts.optimize_ic \
  --start 2020-01-01 --end 2023-12-31 \
  --tickers SPY QQQ \
  --dtes 7 14 21 \
  --wings 2 3 5 \
  --ptails 0.10 0.20 \
  --edges -2.5 0 2.5 5 \
  --train_years 2 --test_months 3 \
  --outroot data/opt_ic_mid

# Broad (safer grid for single names)
python -m scripts.optimize_ic \
  --start 2019-01-01 --end 2024-12-31 \
  --tickers SPY QQQ AAPL MSFT NVDA \
  --dtes 14 21 28 35 45 \
  --wings 3 5 7 10 \
  --ptails 0.10 0.15 0.20 0.25 \
  --edges 0 2.5 5 7.5 \
  --train_years 2 --test_months 3 \
  --outroot data/opt_ic_broad

echo
echo "---- Quick summaries ----"
for root in data/opt_ic_smoke data/opt_ic_mid data/opt_ic_broad; do
  echo "=== Summary for $root ==="
  csv="$root/ic_benchmark_compare_eqw.csv"
  if [[ -f "$csv" ]]; then
    CSV_PATH="$csv" python - <<'PY'
import pandas as pd, numpy as np, json, os
csv = os.environ.get("CSV_PATH")
try:
    comp = pd.read_csv(csv)
    if comp.empty or "dSharpe" not in comp.columns:
        raise RuntimeError("empty or malformed benchmark compare")
    ok = comp.replace([np.inf,-np.inf], np.nan).dropna(subset=["strat_Sharpe","bench_Sharpe"])
    beats = int((ok["dSharpe"] > 0).sum())
    tot   = int(len(ok))
    mean_d= float(ok["dSharpe"].mean()) if tot else float("nan")
    med_d = float(ok["dSharpe"].median()) if tot else float("nan")
    tot_tr = int(ok["n_trades"].fillna(0).sum()) if "n_trades" in ok.columns else 0
    worst_dd = float(ok["strat_MaxDD"].min()) if "strat_MaxDD" in ok.columns else float("nan")
    print(json.dumps({
      "folds_compared": tot,
      "beats_sharpe": beats,
      "mean_dSharpe": round(mean_d,3) if np.isfinite(mean_d) else None,
      "median_dSharpe": round(med_d,3) if np.isfinite(med_d) else None,
      "total_trades": tot_tr,
      "worst_OOS_MaxDD": round(worst_dd,3) if np.isfinite(worst_dd) else None
    }, indent=2))
except Exception as e:
    print(f"(could not summarize: {e})")
PY
  else
    echo "(no benchmark CSV found)"
  fi
done
