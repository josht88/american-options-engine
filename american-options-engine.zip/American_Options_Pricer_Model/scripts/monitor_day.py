#!/usr/bin/env python
"""
Daily close monitor (“post-flop”).

Tasks
-----
1. Read ledger (data/pnl.csv)
2. For every OPEN leg:
      • mark to market
      • check early-exercise (American puts)
3. Update ledger rows (mark / realised / tag).
"""

import csv
import json
import math
import pathlib
import datetime as dt
from typing import List, Dict

import pandas as pd

from aoe.pnl import ledger
from aoe.pnl.ledger import update_marks
from aoe.monitor.early import mark_and_check
from aoe.models.heston import HestonModel

# ---------- constants ----------------------------------------------------
R, Q = 0.02, 0.0  # flat curves
MODEL_DIR = pathlib.Path("data/models")

# ---------- optional fast MTM module ------------------------------------
try:
    from aoe.pnl import mtm  # type: ignore
    HAS_MTM = hasattr(mtm, "mark_open_legs")
except Exception:
    mtm = None  # type: ignore
    HAS_MTM = False


# ---------- helpers ------------------------------------------------------
def _load_model(ticker: str, spot: float) -> HestonModel:
    """
    Load the most recent calibration json for `ticker`.
    """
    files = sorted(MODEL_DIR.glob(f"{ticker}_*.json"))
    if not files:
        raise FileNotFoundError(f"No model json for {ticker} in {MODEL_DIR}")
    with files[-1].open() as f:
        data = json.load(f)
    # Support both old (flat keys) and new schema
    params = data.get("params", data)
    mdl = HestonModel(**params)
    mdl.spot = spot
    return mdl


def _fetch_spot(ticker: str) -> float:
    """Quick spot fetch via yfinance (or stub it in tests)."""
    import yfinance as yf

    try:
        return float(yf.Ticker(ticker).fast_info["lastPrice"])
    except Exception:
        # fail safe: return NaN; caller may decide what to do
        return math.nan


def _fallback_mark(rows: List[Dict]) -> List[Dict]:
    """
    Slow python loop if vectorised mtm is unavailable.
    Uses mark_and_check() for each leg.
    """
    out: List[Dict] = []
    today = dt.date.today()
    for r in rows:
        if r.get("tag") != "OPEN":
            continue

        ticker = r["ticker"]
        expiry = pd.to_datetime(r["expiry"]).date()
        dte = (expiry - today).days

        spot = _fetch_spot(ticker)
        if math.isnan(spot):
            # if no spot, skip marking (leave mark blank)
            out.append({**r, "mark": r.get("mark", ""), "realised": r.get("realised", ""), "tag": r.get("tag", "OPEN")})
            continue

        mdl = _load_model(ticker, spot)

        res = mark_and_check(
            mdl,
            r["right"],
            spot,
            float(r["long_k"]),
            R,
            Q,
            dte,
            int(r["qty"]),
            short_k=float(r.get("short_k") or 0.0),
        )

        tag = "CLOSED" if res["exercise"] else "OPEN"
        out.append(
            dict(
                ticker=ticker,
                expiry=r["expiry"],
                right=r["right"],
                long_k=r["long_k"],
                short_k=r["short_k"],
                mark=res["mark"],
                realised=res["pnl_if_ex"],
                tag=tag,
            )
        )
    return out


# ---------- main runner --------------------------------------------------
def run():
    if not ledger.LEDGER.exists():
        print("No open trades.")
        return

    rows = list(csv.DictReader(ledger.LEDGER.open()))
    if not any(r.get("tag") == "OPEN" for r in rows):
        print("No open trades.")
        return

    # Mark them
    if HAS_MTM:
        try:
            marks = mtm.mark_open_legs(rows, _load_model, _fetch_spot, R, Q)
        except Exception:
            marks = _fallback_mark(rows)
    else:
        marks = _fallback_mark(rows)

    update_marks(marks)
    print(f"Marked {len(marks)} legs.")


if __name__ == "__main__":
    run()
