#!/usr/bin/env python
"""Lightweight PnL dashboard – run with:  streamlit run scripts/pnl_app.py """

import pandas as pd
import pathlib, datetime as dt, math
import streamlit as st
from aoe.pnl.ledger import LEDGER

st.set_page_config(page_title="AOE PnL", layout="wide")

# ---------- load ------------------------------------------------------------
if not LEDGER.exists():
    st.warning("No ledger yet – place a trade first!")
    st.stop()

df = pd.read_csv(LEDGER, parse_dates=["ts"])
df["mark"]     = df["mark"].astype(float)
df["realised"] = df["realised"].astype(float)
df["price"]    = df["price"].astype(float)

# open / closed split
open_pos  = df[df["tag"] == "OPEN"].copy()
closed    = df[df["tag"] == "CLOSED"].copy()

# ---------- sidebar filters -------------------------------------------------
st.sidebar.header("Filters")
tickers = st.sidebar.multiselect(
    "Ticker", sorted(df["ticker"].unique()), default=list(df["ticker"].unique())
)
open_pos = open_pos[open_pos["ticker"].isin(tickers)]
closed   = closed[closed["ticker"].isin(tickers)]

# ---------- PnL calc --------------------------------------------------------
open_pos["unreal"] = (open_pos["mark"] - open_pos["price"]) * open_pos["qty"]
open_pos["delta$"] = open_pos["unreal"] + open_pos["realised"]

daily = (
    df.assign(
        pnl=lambda d: (d["mark"] - d["price"]) * d["qty"] + d["realised"]
    )
    .groupby(df["ts"].dt.date)["pnl"]
    .sum()
    .cumsum()
)

# ---------- layout ----------------------------------------------------------
st.title("American-Options Engine – Portfolio PnL")

col1, col2 = st.columns((2, 1))

with col1:
    st.subheader("Cumulative PnL")
    st.line_chart(daily)

with col2:
    st.metric(
        "Total 👁️‍🗨️",
        f"${daily.iloc[-1]:,.0f}",
        help="Realised + Unrealised"
    )
    st.metric("Open positions", len(open_pos))

st.subheader("Open Legs")
st.dataframe(
    open_pos[
        ["ticker","expiry","right","long_k","short_k",
         "qty","price","mark","unreal","realised"]
    ].round(2),
    use_container_width=True,
)

with st.expander("Closed Legs"):
    st.dataframe(
        closed[
            ["ticker","expiry","right","long_k","short_k",
             "qty","price","realised"]
        ].round(2),
        use_container_width=True,
    )

st.caption(
    f"Last updated {dt.datetime.utcnow().isoformat(timespec='seconds')} UTC • "
    "App auto-reloads on file change."
)
