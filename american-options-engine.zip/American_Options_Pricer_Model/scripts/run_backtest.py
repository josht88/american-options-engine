#!/usr/bin/env python
"""
Run a quick condor-selling backtest on your blue-chip sandbox.

Examples:
  python -m scripts.run_backtest --months 6
  python -m scripts.run_backtest --start 2024-07-01 --end 2025-07-01 --tickers AAPL MSFT SPY
"""

import argparse, datetime as dt, json
from aoe.backtest.engine import run_with_yfinance
from aoe.universe import BLUE_CHIPS


def _parse_args():
    p = argparse.ArgumentParser()
    p.add_argument("--tickers", nargs="*", default=BLUE_CHIPS[:10])
    p.add_argument("--start", type=str, default="")
    p.add_argument("--end", type=str, default="")
    p.add_argument("--months", type=int, default=6)
    p.add_argument("--dte", type=int, default=21)
    p.add_argument("--p_tail", type=float, default=0.20)
    p.add_argument("--wing", type=float, default=5.0)
    p.add_argument("--slip_bps", type=float, default=5.0)
    p.add_argument("--bankroll", type=float, default=100_000.0)
    p.add_argument("--risk_frac", type=float, default=0.05)
    p.add_argument("--cadence", type=int, default=5)
    return p.parse_args()


def main():
    args = _parse_args()
    if args.start and args.end:
        start = dt.date.fromisoformat(args.start)
        end   = dt.date.fromisoformat(args.end)
    else:
        end = dt.date.today()
        start = end - dt.timedelta(days=30*args.months)

    results = run_with_yfinance(
        args.tickers, start, end,
        dte_days=args.dte, p_tail=args.p_tail, wing_width=args.wing,
        slippage_bps=args.slip_bps, bankroll=args.bankroll,
        max_risk_frac=args.risk_frac, trade_every_n_days=args.cadence,
    )

    print("\n=== Backtest summary ===")
    agg_pnl = 0.0
    for tk, res in results.items():
        r = res["report"]
        agg_pnl += r["pnl"]
        print(f"{tk:5s}  trades={r['trades']:3d}  pnl=${r['pnl']:8.2f}  ret={r['ret_pct']:6.2f}%  "
              f"wins={r['wins']:2d}/{r['trades']:3d}  maxDD={r['max_dd']:.2%}")
    print(f"\nTOTAL pnl=${agg_pnl:,.2f}")

if __name__ == "__main__":
    main()
