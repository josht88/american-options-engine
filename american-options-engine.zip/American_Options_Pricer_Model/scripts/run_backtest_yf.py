#!/usr/bin/env python
from __future__ import annotations
import argparse, json, os, pathlib
import pandas as pd

# Your existing APIs
from aoe.backtest.yfbt import backtest_universe, backtest_ticker
from aoe.universe import BLUE_CHIPS

# Optional: config + metrics (added)
try:
    from aoe.config import AOEConfig
    HAVE_CFG = True
except Exception:
    HAVE_CFG = False

try:
    from aoe.metrics import summarize
    HAVE_METRICS = True
except Exception:
    HAVE_METRICS = False


def _parse_args():
    p = argparse.ArgumentParser("AOE YFinance Backtests")
    # NEW: optional config path
    p.add_argument("--config", type=str, help="experiments/.yaml (optional)")

    # Original CLI (kept)
    p.add_argument("--tickers", nargs="*", default=BLUE_CHIPS)
    p.add_argument("--start", type=str)
    p.add_argument("--end",   type=str)
    p.add_argument("--strategy", choices=["condor","debit","both"], default="condor")
    p.add_argument("--dte", type=int, default=21)
    p.add_argument("--step", type=int, default=5)
    p.add_argument("--p_tail", type=float, default=0.20)
    # Keep original flag name `--wing`; map to wing_width in engine
    p.add_argument("--wing", type=float, default=5.0)
    p.add_argument("--slip_bps", type=float, default=20.0)
    p.add_argument("--fee", type=float, default=0.65)
    p.add_argument("--risk_frac", type=float, default=0.01)
    p.add_argument("--save_trades", action="store_true")
    # Optional override of output root
    p.add_argument("--outroot", type=str, help="override output directory root")
    return p.parse_args()


def _merge_args_with_config(a: argparse.Namespace):
    """
    If --config provided and aoe.config available, load YAML and fill any missing CLI fields.
    CLI flags still take precedence when explicitly set.
    """
    if not getattr(a, "config", None) or not HAVE_CFG:
        return a, None

    cfg = AOEConfig.load(a.config, {}).raw

    # Data
    if not a.start:   a.start   = cfg.get("data", {}).get("start")
    if not a.end:     a.end     = cfg.get("data", {}).get("end")
    if (not a.tickers or a.tickers == BLUE_CHIPS) and cfg.get("data", {}).get("universe"):
        a.tickers = cfg["data"]["universe"]

    # Strategy
    strat = cfg.get("strategy", {})
    if a.strategy == "condor" and strat.get("kind"):        a.strategy  = strat["kind"]
    if a.dte == 21 and strat.get("dte") is not None:        a.dte       = int(strat["dte"])
    if a.step == 5 and strat.get("step_days") is not None:  a.step      = int(strat["step_days"])
    if a.p_tail == 0.20 and strat.get("p_tail") is not None:a.p_tail    = float(strat["p_tail"])
    if a.wing == 5.0 and strat.get("wing_width") is not None:
        a.wing = float(strat["wing_width"])

    # Costs / risk
    costs = cfg.get("costs", {})
    if a.fee == 0.65 and costs.get("fee_per_contract") is not None:
        a.fee = float(costs["fee_per_contract"])
    risk  = cfg.get("risk", {})
    if a.risk_frac == 0.01 and risk.get("kelly_cap_pct") is not None:
        a.risk_frac = float(risk["kelly_cap_pct"]) / 100.0

    # Outputs
    outroot = cfg.get("outputs", {}).get("root", None)
    name    = cfg.get("meta", {}).get("name", None)
    return a, {"outroot": outroot, "name": name, "cfg": cfg}


def _ensure_equity_df(equity) -> pd.DataFrame:
    """
    Normalize portfolio equity to a DataFrame with columns ['date','equity'].
    Accepts pd.Series(date-indexed) or a 2-col DataFrame.
    """
    if isinstance(equity, pd.Series):
        df = equity.copy()
        df.name = "equity"
        df = df.reset_index()
        # Force canonical column names regardless of original casing/names
        if len(df.columns) != 2:
            raise TypeError("Expected equity Series to reset to 2 columns (index + values).")
        df.columns = ["date", "equity"]
        return df

    elif isinstance(equity, pd.DataFrame):
        if len(equity.columns) != 2:
            raise TypeError("Expected equity DataFrame to have exactly 2 columns.")
        df = equity.copy()
        df.columns = ["date", "equity"]
        return df

    raise TypeError("Unsupported equity output; expected Series or 2-col DataFrame.")

# --- replace the whole helper ---
def _coerce_equity_curve(equity_df: pd.DataFrame, target_total_pnl: float | None = None, base: float = 100000.0) -> pd.DataFrame:
    """
    If 'equity' is daily P&L (ends near 0), convert to cumulative (cumsum) so the
    final value ~ total P&L. Then add a base to produce a positive equity curve.
    """
    df = equity_df.copy()
    eq = df["equity"].astype(float)
    if len(eq) == 0:
        return df

    # If we know portfolio total P&L from summaries, decide whether to cumsum
    if target_total_pnl is not None:
        last_raw = float(eq.iloc[-1])
        last_cum = float(eq.cumsum().iloc[-1])
        # Choose whichever ending value is closer to the portfolio total P&L
        if abs(last_cum - target_total_pnl) < abs(last_raw - target_total_pnl):
            eq = eq.cumsum()
            df["equity"] = eq

    # Ensure positive equity curve (not near/through zero)
    if df["equity"].iloc[0] <= 0 or df["equity"].min() <= 0:
        df["equity"] = base + df["equity"].astype(float)

    return df

def _aggregate_trades(tickers, start, end, params, outdir: pathlib.Path, save_per_ticker: bool):
    """
    Collect raw trade rows per ticker (as emitted by backtest_ticker) and write them.
    We intentionally keep raw rows; portfolio metrics are derived from the equity curve.
    Returns: trades_raw_df (pd.DataFrame).
    """
    import pandas as pd

    frames = []
    for tk in tickers:
        try:
            r = backtest_ticker(tk, start, end, **params)
        except Exception:
            continue
        trades = r.get("trades", [])
        if not trades:
            continue

        # Convert list of trade objects -> DataFrame
        df = pd.DataFrame([t.__dict__ for t in trades])

        # Normalize basic naming
        if "pnl" in df.columns and "realised" not in df.columns:
            df = df.rename(columns={"pnl": "realised"})
        df["ticker"] = tk

        frames.append(df)

        if save_per_ticker:
            df.to_csv(outdir / f"trades_{tk}.csv", index=False)

    trades_raw = (
        pd.concat(frames, ignore_index=True)
        if frames else pd.DataFrame({"realised": pd.Series(dtype=float)})
    )
    return trades_raw

def main():
    import pandas as pd  # local import to keep module surface small

    a = _parse_args()
    a, cfg_meta = _merge_args_with_config(a)

    # --- NEW: normalize comma-joined tickers from CLI ---
    if isinstance(a.tickers, str):
        a.tickers = [t.strip() for t in a.tickers.split(",") if t.strip()]
    elif isinstance(a.tickers, (list, tuple)) and len(a.tickers) == 1 and isinstance(a.tickers[0], str) and "," in a.tickers[0]:
        a.tickers = [t.strip() for t in a.tickers[0].split(",") if t.strip()]

    # Validate required dates
    if not a.start or not a.end:
        raise SystemExit("ERROR: --start and --end are required (or provide them via --config).")

    # Run the portfolio backtest once
    params = dict(
        strategy=a.strategy,
        dte_days=a.dte,
        step_days=a.step,
        p_tail=a.p_tail,
        wing_width=a.wing,
        slip_bps=a.slip_bps,
        fee_per_contract=a.fee,
        risk_per_trade=a.risk_frac,
    )
    res = backtest_universe(a.tickers, a.start, a.end, **params)
    summaries: pd.DataFrame = res["summaries"]
    equity = res["equity"]

    total = float(summaries["pnl"].sum()) if "pnl" in summaries.columns else None

    root = a.outroot or ((cfg_meta and cfg_meta.get("outroot")) or "data/backtests")
    runname = (cfg_meta["name"] if (cfg_meta and cfg_meta.get("name")) else f"{a.strategy}")
    outdir = pathlib.Path(root) / f"{runname}_{a.start}_{a.end}"
    outdir.mkdir(parents=True, exist_ok=True)

    summaries.to_csv(outdir / "summaries.csv", index=False)

    equity_df = _ensure_equity_df(equity)
    equity_df = _coerce_equity_curve(equity_df, target_total_pnl=total)
    equity_df.to_csv(outdir / "equity.csv", index=False)

    trades_df = _aggregate_trades(
        a.tickers, a.start, a.end, params, outdir, save_per_ticker=a.save_trades
    )
    trades_df.to_csv(outdir / "trades.csv", index=False)

    if total is None:
        total = float(trades_df["realised"].sum() if ("realised" in trades_df.columns and not trades_df.empty) else 0.0)

    print("\n=== Portfolio ===")
    print(summaries.assign(total_pnl=total).to_string(index=False))

    print("\n=== Per-ticker summary ===")
    if "ticker" in summaries.columns:
        for r in summaries.itertuples(index=False):
            tk = getattr(r, "ticker", "NA")
            pnl = getattr(r, "pnl", 0.0)
            trades = int(getattr(r, "trades", 0))
            wins = int(getattr(r, "wins", 0))
            ret_pct = getattr(r, "ret_pct", 0.0)
            max_dd = getattr(r, "max_dd", 0.0)
            print(f"{tk:>5s}  pnl={pnl:10.6f}  trades={trades:3d}  wins={wins:2d}  ret={ret_pct:8.6f}  maxDD={max_dd: .6f}")

    trades_total_raw = float(trades_df["realised"].sum()) if ("realised" in trades_df.columns and not trades_df.empty) else 0.0
    print(f"\n[AUDIT] summaries_total_pnl={total:.2f}  trades_total_raw={trades_total_raw:.2f}  n_trades_raw={len(trades_df)}")
    print("[AUDIT] Note: totals may differ because portfolio summaries apply distinct aggregation "
          "(sizing/costs/overlaps) vs per-row realised. Use equity.csv for performance metrics.")

    if HAVE_METRICS:
        empty_trades = pd.DataFrame({"realised": pd.Series(dtype=float)})
        metrics = summarize(equity_df, empty_trades)
        with open(outdir / "metrics.json", "w") as f:
            json.dump(metrics, f, indent=2)
        print("\n=== Metrics (equity-derived) ===")
        print(json.dumps(metrics, indent=2))
    else:
        print("\n(No aoe.metrics module found; skipping metrics.json)")

    print(f"\nSaved to: {outdir}")


if __name__ == "__main__":
    main()
