# Makes `scripts` importable as a package
