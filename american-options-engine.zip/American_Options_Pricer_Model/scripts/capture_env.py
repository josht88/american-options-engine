# scripts/capture_env.py
from __future__ import annotations
import json, os, platform, subprocess, sys
from datetime import datetime, UTC

def main():
    import argparse
    ap = argparse.ArgumentParser("Capture environment info for a run directory")
    ap.add_argument("--outdir", required=True, help="Path to a backtest run folder")
    args = ap.parse_args()

    os.makedirs(args.outdir, exist_ok=True)

    def _ver(mod):
        try:
            return __import__(mod).__version__
        except Exception:
            return None

    # try to get git commit (if repo)
    try:
        sha = subprocess.check_output(["git", "rev-parse", "HEAD"], text=True).strip()
        dirty = subprocess.check_output(["git", "status", "--porcelain"], text=True).strip() != ""
        git = {"sha": sha, "dirty": dirty}
    except Exception:
        git = None

    info = {
        "captured_at": datetime.now(UTC).isoformat(timespec="seconds"),
        "python": sys.version.replace("\n", " "),
        "platform": {
            "system": platform.system(),
            "release": platform.release(),
            "machine": platform.machine(),
        },
        "packages": {
            "numpy": _ver("numpy"),
            "pandas": _ver("pandas"),
            "pyyaml": _ver("yaml"),
            "yfinance": _ver("yfinance"),
            "quantlib": _ver("QuantLib") or _ver("quantlib"),
        },
        "git": git,
    }

    with open(os.path.join(args.outdir, "env.json"), "w") as f:
        json.dump(info, f, indent=2)
    print(f"Wrote {os.path.join(args.outdir,'env.json')}")
if __name__ == "__main__":
    main()
