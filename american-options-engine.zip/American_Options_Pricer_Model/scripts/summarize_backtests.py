# scripts/summarize_backtests.py
from __future__ import annotations
import json, os, glob, pandas as pd, argparse

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--root", type=str, default="data/backtests")
    ap.add_argument("--out", type=str, default="data/backtests/leaderboard.csv")
    args = ap.parse_args()

    rows = []
    for mpath in glob.glob(os.path.join(args.root, "**/metrics.json"), recursive=True):
        with open(mpath, "r") as f:
            m = json.load(f)
        parts = mpath.replace("\\","/").split("/")
        run_dir = "/".join(parts[-2:])
        rows.append({"run": run_dir, **m})
    df = pd.DataFrame(rows)
    if not df.empty:
        df = df.sort_values(by=["Sharpe","CAGR","MAR"], ascending=[False,False,False])
    os.makedirs(os.path.dirname(args.out), exist_ok=True)
    df.to_csv(args.out, index=False)
    print(f"Wrote {args.out} with {len(df)} rows.")

if __name__ == "__main__":
    main()
