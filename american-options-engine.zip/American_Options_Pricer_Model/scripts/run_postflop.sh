#!/usr/bin/env bash
set -euo pipefail
export AOE_LEDGER="${AOE_LEDGER:-data/pnl_paper.csv}"

mkdir -p logs
# Ensure ledger exists ahead of time as well
python -c "from aoe.pnl.ledger import ensure_ledger_exists; p=ensure_ledger_exists(); print(f'[init-ledger] ensured {p}')" | tee -a logs/postflop.log

echo "[$(date -u +'%FT%TZ')] monitor_day starting (AOE_LEDGER=$AOE_LEDGER)" | tee -a logs/postflop.log
python -m scripts.monitor_day >> logs/postflop.log 2>&1 || {
  echo "[$(date -u +'%FT%TZ')] monitor_day failed" | tee -a logs/postflop.log
  exit 1
}
echo "[$(date -u +'%FT%TZ')] monitor_day finished" | tee -a logs/postflop.log
