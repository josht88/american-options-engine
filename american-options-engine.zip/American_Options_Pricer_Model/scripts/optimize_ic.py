#!/usr/bin/env python3
"""
Optimize Iron Condor parameters with walk-forward selection, plus benchmarking.

- Grid-search on a training window (e.g., 24 months)
- Pick a robust winner (Sharpe up, MaxDD down, min trades, DD guardrail)
- Trade that combo on the next test window (e.g., 3 months)
- Roll forward across the whole period

Saves:
  * <outroot>/ic_walkforward_folds.csv
  * <outroot>/ic_walkforward_recommendation.json
  * <outroot>/ic_benchmark_compare_eqw.csv   (equal-weight buy&hold of your tickers)

This relies on your existing backtest engine:
  aoe.backtest.yfbt.backtest_universe(tickers, start, end, **params)
"""

from __future__ import annotations

# ------------------------------ stdlib -----------------------------------
import argparse
import datetime as dt
import json
import math
import os
import pathlib
import sys
import time
from dataclasses import dataclass
from itertools import product
from typing import Any, Dict, Iterable, List, Optional, Tuple

# ------------------------------ third-party ------------------------------
import numpy as np
import pandas as pd

# yfinance (for preflight data checks + benchmark)
import logging
logging.getLogger("yfinance").setLevel(logging.ERROR)
import yfinance as yf

# ------------------------------ repo-local --------------------------------
ROOT = pathlib.Path(__file__).resolve().parents[1]
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

from aoe.backtest.yfbt import backtest_universe  # type: ignore


# ============================== data guards ==============================

def fetch_ohlc_yf(ticker: str, start: str, end: str, *, max_retries: int = 3) -> pd.DataFrame:
    """
    Robust daily OHLC downloader for yfinance:
      - tries both download() and Ticker().history()
      - threads=False for stability, repair=True to fix gaps
      - retries with short backoff when empty
      - returns a DataFrame (may be empty), index is DatetimeIndex
    """
    last_err: Optional[Exception] = None
    for attempt in range(1, max_retries + 1):
        try:
            df = yf.download(
                tickers=ticker,
                start=start, end=end,
                interval="1d",
                auto_adjust=False,
                progress=False,
                threads=False,
                repair=True,
            )
            if isinstance(df, pd.DataFrame) and not df.empty:
                if "Adj Close" in df.columns and "Close" not in df.columns:
                    df = df.rename(columns={"Adj Close": "Close"})
                return df.copy()

            t = yf.Ticker(ticker)
            df = t.history(
                start=start, end=end, interval="1d",
                auto_adjust=False, actions=False, repair=True
            )
            if isinstance(df, pd.DataFrame) and not df.empty:
                if "adjclose" in df.columns and "Close" not in df.columns:
                    df = df.rename(columns={"adjclose": "Close"})
                return df.copy()

            time.sleep(0.6 * attempt)
        except Exception as e:
            last_err = e
            time.sleep(0.6 * attempt)

    if last_err:
        print(f"[data] {ticker} empty after retries ({start}→{end}): {last_err}")
    return pd.DataFrame()


def _load_fold_data(tickers: Iterable[str], start: str, end: str) -> Dict[str, pd.DataFrame]:
    """
    Pre-flight check for a fold's date window.
    Raises if *all* tickers are empty, logs if some are empty.
    """
    tickers = list(tickers)
    data = {t: fetch_ohlc_yf(t, start, end) for t in tickers}
    empties = [t for t, df in data.items() if df.empty]
    if len(empties) == len(tickers):
        raise RuntimeError(f"no price data for any ticker in {start}→{end} (e.g., {', '.join(empties[:5])})")
    if empties:
        print(f"[data] missing {len(empties)}/{len(tickers)} tickers this fold: {', '.join(empties[:10])}")
    return data


# ============================== metric utils =============================

def _equity_to_metrics(equity_obj: Any) -> Dict[str, float]:
    """
    Compute robust metrics from a backtest 'equity' object.

    Accepts:
      - pd.Series (index: date-like, values: cumulative PnL or capital)
      - pd.DataFrame with columns ['date','equity'] or single column
    Normalization:
      - If series looks like cumulative P&L (starts around 0), we build a synthetic
        capital curve starting at 100.0 and add PnL to it. Metrics are then computed
        on that capital curve (pct returns, bounded drawdowns).
    Returns:
      dict(CAGR, Sharpe, MaxDD, Vol)
    """
    # ---- normalize to DataFrame with ['date','equity'] ----
    if isinstance(equity_obj, pd.Series):
        df = equity_obj.rename("equity").reset_index()
        df.columns = ["date", "equity"]
    elif isinstance(equity_obj, pd.DataFrame):
        if "equity" in equity_obj.columns and "date" in equity_obj.columns:
            df = equity_obj[["date", "equity"]].copy()
        else:
            if "equity" in equity_obj.columns:
                df = equity_obj[["equity"]].reset_index().rename(columns={equity_obj.index.name or "index": "date"})
            elif equity_obj.shape[1] == 1:
                df = equity_obj.copy()
                df.columns = ["equity"]
                df = df.reset_index().rename(columns={df.index.name or "index": "date"})
            else:
                # Best-effort: pick first numeric column as equity
                num_cols = [c for c in equity_obj.columns if pd.api.types.is_numeric_dtype(equity_obj[c])]
                if not num_cols:
                    return dict(CAGR=float("nan"), Sharpe=float("nan"), MaxDD=float("nan"), Vol=float("nan"))
                df = equity_obj[[num_cols[0]]].copy()
                df.columns = ["equity"]
                df = df.reset_index().rename(columns={df.index.name or "index": "date"})
    else:
        return dict(CAGR=float("nan"), Sharpe=float("nan"), MaxDD=float("nan"), Vol=float("nan"))

    if df.empty:
        return dict(CAGR=float("nan"), Sharpe=float("nan"), MaxDD=float("nan"), Vol=float("nan"))

    # ---- clean types ----
    df["date"] = pd.to_datetime(df["date"], errors="coerce")
    df = df.dropna(subset=["date"]).sort_values("date")
    df["equity"] = pd.to_numeric(df["equity"], errors="coerce")
    df = df.dropna(subset=["equity"])
    if df.empty:
        return dict(CAGR=float("nan"), Sharpe=float("nan"), MaxDD=float("nan"), Vol=float("nan"))

    # ---- build capital curve starting at 100 ----
    e = df["equity"].values.astype(float)
    start = e[0]
    cap = 100.0 + (e - start)  # capitalized equity
    cap_series = pd.Series(cap, index=df["date"])

    # ---- returns, vol, sharpe ----
    rets = cap_series.pct_change().dropna()
    if rets.empty:
        sharpe = float("nan")
        vol = float("nan")
    else:
        vol = float(rets.std(ddof=1) * math.sqrt(252))
        sharpe = float((rets.mean() / (rets.std(ddof=1) + 1e-12)) * math.sqrt(252))

    # ---- max drawdown (percent from peak, negative fraction) ----
    peak = np.maximum.accumulate(cap)
    dd = (cap - peak) / peak
    maxdd = float(dd.min()) if len(dd) else float("nan")

    # ---- normalize/cap MaxDD to [-1, 0]; rescale percent-style inputs ----
    if np.isfinite(maxdd):
        if abs(maxdd) > 2.0:       # if engine fed -35 for -35%
            maxdd = maxdd / 100.0
        maxdd = float(max(-1.0, min(0.0, maxdd)))

    # ---- CAGR on capital curve ----
    days = (df["date"].iloc[-1] - df["date"].iloc[0]).days
    if days <= 0:
        cagr = float("nan")
    else:
        years = days / 365.25
        start_cap = float(cap[0])
        end_cap = float(cap[-1])
        if start_cap <= 0 or end_cap <= 0:
            cagr = float("nan")
        else:
            cagr = float((end_cap / start_cap) ** (1 / years) - 1)

    return dict(CAGR=cagr, Sharpe=sharpe, MaxDD=maxdd, Vol=vol)


def _strategy_param_name() -> str:
    """Prefer condor; fallback to both if condor unsupported."""
    return "condor"


def _run_backtest(
    tickers: List[str],
    start: str,
    end: str,
    dte_days: int,
    wing_width: float,
    p_tail: float,
    edge_min_pct: float,
    *,
    risk_per_trade: float = 0.01,
    slip_bps: float = 20.0,
    fee_per_contract: float = 0.65,
) -> Dict[str, Any]:
    params = dict(
        strategy=_strategy_param_name(),
        dte_days=int(dte_days),
        step_days=5,
        p_tail=float(p_tail),
        wing_width=float(wing_width),
        min_edge_pct=float(edge_min_pct),
        slip_bps=float(slip_bps),
        fee_per_contract=float(fee_per_contract),
        risk_per_trade=float(risk_per_trade),
    )
    try:
        res = backtest_universe(tickers, start, end, **params)
    except TypeError:
        # Older engines may not recognize some params; drop gracefully
        params.pop("min_edge_pct", None)
        params.pop("wing_width", None)
        try:
            res = backtest_universe(tickers, start, end, **params)
        except TypeError:
            params["strategy"] = "both"
            res = backtest_universe(tickers, start, end, **params)
    return res


# ============================= grid evaluator ============================

@dataclass
class Combo:
    dte: int
    wing: float
    p_tail: float
    edge: float

# robust selection knobs
DD_TARGET  = 0.10    # penalty kicks in beyond |MaxDD| > 10%
LAMBDA_DD  = 1.5     # penalty weight
HARD_DD_CUTOFF = 0.25  # reject combos with |MaxDD| > 25% on TRAIN


def _score_row(row: pd.Series) -> float:
    """
    Higher is better. Base = Sharpe.
    Penalty if |MaxDD| exceeds DD_TARGET (both are positive magnitudes here).
    """
    sharpe = float(row.get("Sharpe", float("nan")))
    maxdd  = row.get("MaxDD", float("nan"))
    if not np.isfinite(sharpe):
        return -1e9

    # normalize MaxDD to fraction and cap
    if np.isfinite(maxdd) and abs(maxdd) > 2.0:
        maxdd = maxdd / 100.0
    if np.isfinite(maxdd):
        maxdd = max(-1.0, min(0.0, float(maxdd)))

    dd_mag = abs(maxdd) if np.isfinite(maxdd) else np.nan
    penalty = 0.0
    if np.isfinite(dd_mag) and dd_mag > DD_TARGET:
        penalty = LAMBDA_DD * (dd_mag - DD_TARGET)
    return float(sharpe - penalty)


def _print_progress(prefix: str, i: int, n: int, last_print: List[int]) -> None:
    """
    Lightweight console progress printer.
    Prints at 0%, 10%, 20%, ... , 100% (or at least every 50 combos).
    """
    if n <= 0:
        return
    pct = int((i / n) * 100)
    milestone = pct // 10
    if n >= 200:
        must_print = (i == n) or (pct == 0 and i == 1) or (milestone > last_print[0])
    else:
        must_print = (i == n) or (i % 50 == 0) or (i == 1)
    if must_print:
        print(f"{prefix} {i}/{n} ({pct:3d}%)")
        last_print[0] = milestone


def optimize_grid_one_fold(
    tickers: List[str],
    start: str,
    end: str,
    combos: List[Tuple[int, float, float, float]],
    *,
    verbose_prefix: Optional[str] = None,
) -> pd.DataFrame:
    """
    Evaluate a grid of (dte, wing, p_tail, edge_min) over [start, end] for the given tickers.
    Returns a DataFrame where each row is a combo with metrics. Never raises; includes 'error' on failure.
    """
    rows: List[Dict[str, Any]] = []
    n = len(combos)
    last_print = [-1]
    for idx, (dte, wing, p_tail, edge_min) in enumerate(combos, start=1):
        if verbose_prefix:
            _print_progress(verbose_prefix, idx, n, last_print)

        strat = _strategy_param_name()
        try:
            params = dict(
                strategy=strat,
                dte_days=int(dte),
                step_days=5,
                p_tail=float(p_tail),
                wing_width=float(wing),
                slip_bps=20.0,
                fee_per_contract=0.65,
                risk_per_trade=0.01,
                min_edge_pct=float(edge_min),
            )

            # --- run backtest with robust fallbacks ---
            try:
                res = backtest_universe(tickers, start, end, **params)
            except TypeError:
                p2 = dict(params)
                p2.pop("min_edge_pct", None)
                p2.pop("wing_width", None)
                try:
                    res = backtest_universe(tickers, start, end, **p2)
                except TypeError:
                    p3 = dict(p2)
                    p3["strategy"] = "both"
                    res = backtest_universe(tickers, start, end, **p3)
                    strat = "both"

            # --- capture n_trades if available ---
            n_trades = None
            try:
                if isinstance(res, dict):
                    if "trades" in res and isinstance(res["trades"], (int, float)):
                        n_trades = int(res["trades"])
                    elif "summaries" in res and isinstance(res["summaries"], pd.DataFrame):
                        if "trades" in res["summaries"].columns:
                            n_trades = int(res["summaries"]["trades"].sum())
            except Exception:
                n_trades = None

            # --- metrics: prefer engine's; else compute from equity ---
            if isinstance(res, dict) and isinstance(res.get("metrics"), dict):
                metrics = res["metrics"]
                sharpe = float(metrics.get("Sharpe", float("nan")))
                cagr   = float(metrics.get("CAGR", float("nan")))
                maxdd  = float(metrics.get("MaxDD", metrics.get("Max Drawdown", float("nan"))))
                vol    = float(metrics.get("Vol", metrics.get("Volatility", float("nan"))))
            else:
                equity = res.get("equity") if isinstance(res, dict) else None
                m = _equity_to_metrics(equity)
                sharpe = float(m.get("Sharpe", float("nan")))
                cagr   = float(m.get("CAGR", float("nan")))
                maxdd  = float(m.get("MaxDD", float("nan")))
                vol    = float(m.get("Vol", float("nan")))

            rows.append(dict(
                dte=int(dte), wing=float(wing), p_tail=float(p_tail), edge_min=float(edge_min),
                Sharpe=sharpe, CAGR=cagr, MaxDD=maxdd, Vol=vol,
                error="", strategy=strat, n_trades=n_trades
            ))

        except Exception as e:
            rows.append(dict(
                dte=int(dte), wing=float(wing), p_tail=float(p_tail), edge_min=float(edge_min),
                Sharpe=float("nan"), CAGR=float("nan"), MaxDD=float("nan"), Vol=float("nan"),
                error=str(e), strategy="", n_trades=None
            ))

    if not rows:
        return pd.DataFrame(columns=[
            "dte","wing","p_tail","edge_min","Sharpe","CAGR","MaxDD","Vol","error","strategy","n_trades"
        ])

    df = pd.DataFrame(rows)
    for col in ["Sharpe","CAGR","MaxDD","Vol","error","strategy","n_trades"]:
        if col not in df.columns:
            df[col] = float("nan") if col not in ("error","strategy") else ""

    # Highest Sharpe first, then CAGR; NaNs last
    df = df.sort_values(["Sharpe","CAGR"], ascending=[False, False], na_position="last")

    # log the selected top row (train convenience)
    top = df[df["error"] == ""].head(1)
    if not top.empty:
        r = top.iloc[0]
        try:
            print(f"[select] picked train combo: dte={int(r['dte'])} wing={float(r['wing'])} "
                  f"p_tail={float(r['p_tail'])} edge_min={float(r['edge_min'])}  "
                  f"(Sharpe={float(r['Sharpe']):.3f} MaxDD={float(r['MaxDD']):.3f} "
                  f"n_trades={int(r['n_trades']) if pd.notna(r['n_trades']) else 'NA'})")
        except Exception:
            pass

    return df


# ============================ walk-forward core ==========================

def walkforward_optimize(
    tickers: List[str],
    start: str,
    end: str,
    dtes: Iterable[int],
    wings: Iterable[float],
    ptails: Iterable[float],
    edges: Iterable[float],
    *,
    train_years: int = 2,
    test_months: int = 3,
    outroot: Optional[str] = None,
    save_csv: bool = True,
    min_trades_train: int = 10,
) -> Dict[str, Any]:
    """
    Walk-forward optimization over [start, end].
    Produces per-fold OOS results even when many combos fail, and records error reasons.
    Adds progress prints per fold + per-combo milestones.
    """
    from datetime import date, timedelta

    def _parse_d(s: str) -> date:
        return date.fromisoformat(s)

    def _fmt_d(d: date) -> str:
        return d.strftime("%Y-%m-%d")

    def _add_years(d: date, years: int) -> date:
        try:
            return d.replace(year=d.year + years)
        except ValueError:
            # handle Feb 29 etc.
            if d.month == 2 and d.day in (28, 29):
                return d.replace(year=d.year + years, day=28)
            for day in range(31, 27, -1):
                try:
                    return d.replace(year=d.year + years, day=day)
                except ValueError:
                    continue
            return d.replace(year=d.year + years, day=28)

    def _add_months(d: date, months: int) -> date:
        y = d.year + (d.month - 1 + months) // 12
        m = (d.month - 1 + months) % 12 + 1
        for day in range(min(d.day, 31), 27, -1):
            try:
                return date(y, m, day)
            except ValueError:
                continue
        return date(y, m, 28)

    # Build folds
    start_d, end_d = _parse_d(start), _parse_d(end)
    folds: List[Tuple[date, date, date, date]] = []
    train_start = start_d
    while True:
        train_end = _add_years(train_start, train_years) - timedelta(days=1)
        test_start = train_end + timedelta(days=1)
        test_end = _add_months(test_start, test_months) - timedelta(days=1)
        if test_start > end_d:
            break
        if test_end > end_d:
            test_end = end_d
        if train_start <= train_end and test_start <= test_end:
            folds.append((train_start, train_end, test_start, test_end))
        train_start = _add_months(train_start, test_months)
        if train_start > end_d:
            break

    combos = list(product(list(dtes), list(wings), list(ptails), list(edges)))
    print(f"[setup] tickers={len(tickers)} min_trades_train={min_trades_train} range={start}→{end}")

    all_fold_rows: List[Dict[str, Any]] = []
    for fi, (train_s, train_e, test_s, test_e) in enumerate(folds, start=1):
        train_s_str, train_e_str = _fmt_d(train_s), _fmt_d(train_e)
        test_s_str, test_e_str = _fmt_d(test_s), _fmt_d(test_e)
        print(f"\n[fold {fi}/{len(folds)}] train={train_s_str}→{train_e_str}  "
              f"test={test_s_str}→{test_e_str}")

        # Pre-flight data check for TRAIN and TEST windows
        try:
            _load_fold_data(tickers, train_s_str, train_e_str)
        except RuntimeError as e:
            msg = f"train-precheck-failed: {e}"
            print(f"[fold {fi}] {msg}")
            all_fold_rows.append(dict(
                fold_start=test_s_str, fold_end=test_e_str,
                dte=np.nan, wing=np.nan, p_tail=np.nan, edge_min=np.nan,
                Sharpe=np.nan, CAGR=np.nan, MaxDD=np.nan, Vol=np.nan, n_trades=np.nan,
                error=msg
            ))
            continue

        # Train grid
        print(f"[fold {fi}] train grid start: {len(combos)} combos")
        train_df = optimize_grid_one_fold(
            tickers, train_s_str, train_e_str, combos,
            verbose_prefix=f"[fold {fi}] train "
        )

        ok_train = train_df[train_df["error"] == ""].copy()

        # --- require minimum trades; if that empties, fall back to all ok ---
        ok_train["_n_trades"] = ok_train["n_trades"].fillna(0).astype(int)
        eligible = ok_train[ok_train["_n_trades"] >= int(min_trades_train)]
        candidates = (eligible if not eligible.empty else ok_train).copy()

        if candidates.empty:
            all_fold_rows.append(dict(
                fold_start=test_s_str, fold_end=test_e_str,
                dte=np.nan, wing=np.nan, p_tail=np.nan, edge_min=np.nan,
                Sharpe=np.nan, CAGR=np.nan, MaxDD=np.nan, Vol=np.nan, n_trades=np.nan,
                error=f"no-train-data ({(train_df['error']!='').sum()} failures)"
            ))
            continue

        # --- Hard drawdown guard (reject combos with |MaxDD| > HARD_DD_CUTOFF) ---
        cand = candidates.copy()
        md = cand["MaxDD"].astype(float)

        # rescale if values look like percents (|dd| > 2.0)
        md = np.where(np.isfinite(md) & (np.abs(md) > 2.0), md / 100.0, md)
        md = np.clip(md, -1.0, 0.0)  # ensure in [-1, 0]
        cand["_MaxDD_norm"] = md

        strict = cand[np.abs(cand["_MaxDD_norm"]) <= HARD_DD_CUTOFF].copy()
        candidates = strict if not strict.empty else cand.copy()

        # --- score candidates (Sharpe − penalty(|MaxDD| beyond DD_TARGET)) ---
        candidates = candidates.assign(_score=candidates.apply(_score_row, axis=1))

        best = candidates.sort_values("_score", ascending=False).iloc[0]
        best_combo = (
            int(best["dte"]),
            float(best["wing"]),
            float(best["p_tail"]),
            float(best["edge_min"]),
        )


        print(f"[fold {fi}] selected combo: dte={best_combo[0]} wing={best_combo[1]} "
              f"p_tail={best_combo[2]} edge_min={best_combo[3]}  "
              f"(Sharpe={best['Sharpe']:.3f} CAGR={best['CAGR'] if pd.notna(best['CAGR']) else float('nan'):.3f} "
              f"MaxDD={best['MaxDD']:.3f} Vol={best['Vol']:.3f})")

        # Pre-check TEST window as well
        try:
            _load_fold_data(tickers, test_s_str, test_e_str)
        except RuntimeError as e:
            msg = f"test-precheck-failed: {e}"
            print(f"[fold {fi}] {msg}")
            all_fold_rows.append(dict(
                fold_start=test_s_str, fold_end=test_e_str,
                dte=best_combo[0], wing=best_combo[1], p_tail=best_combo[2], edge_min=best_combo[3],
                Sharpe=np.nan, CAGR=np.nan, MaxDD=np.nan, Vol=np.nan, n_trades=np.nan,
                error=msg
            ))
            continue

        # Test the chosen combo
        print(f"[fold {fi}] test OOS start")
        test_df = optimize_grid_one_fold(
            tickers, test_s_str, test_e_str, [best_combo],
            verbose_prefix=f"[fold {fi}] test  "
        )
        ok_test = test_df[test_df["error"] == ""]
        if ok_test.empty:
            msg = test_df["error"].iloc[0] if not test_df.empty else "no-test-data"
            print(f"[fold {fi}] test failed: {msg}")
            all_fold_rows.append(dict(
                fold_start=test_s_str, fold_end=test_e_str,
                dte=best_combo[0], wing=best_combo[1], p_tail=best_combo[2], edge_min=best_combo[3],
                Sharpe=np.nan, CAGR=np.nan, MaxDD=np.nan, Vol=np.nan, n_trades=np.nan,
                error=msg
            ))
        else:
            tr = ok_test.iloc[0]
            # keep CAGR as-is; we'll suppress noisy short-window annualization at print time
            all_fold_rows.append(dict(
                fold_start=test_s_str, fold_end=test_e_str,
                dte=tr["dte"], wing=tr["wing"], p_tail=tr["p_tail"], edge_min=tr["edge_min"],
                Sharpe=tr["Sharpe"], CAGR=tr["CAGR"], MaxDD=tr["MaxDD"], Vol=tr["Vol"],
                n_trades=(int(tr["n_trades"]) if pd.notna(tr["n_trades"]) else np.nan),
                error=""
            ))

    folds_df = pd.DataFrame(all_fold_rows)
    folds_df = folds_df[["fold_start","fold_end","dte","wing","p_tail","edge_min","Sharpe","CAGR","MaxDD","Vol","n_trades","error"]]

    # Recommendation: pick modal params over recent successful folds
    if folds_df.empty or (folds_df["error"] != "").all():
        recommendation: Dict[str, Any] = {}
    else:
        recent_ok = folds_df[folds_df["error"] == ""].tail(6)
        if recent_ok.empty:
            recommendation = {}
        else:
            def _mode_or_median(series: pd.Series):
                m = series.mode()
                return (m.iloc[0] if not m.empty else series.median())

            recommendation = dict(
                dte=int(_mode_or_median(recent_ok["dte"])),
                wing=float(_mode_or_median(recent_ok["wing"])),
                p_tail=float(_mode_or_median(recent_ok["p_tail"])),
                edge_min=float(_mode_or_median(recent_ok["edge_min"])),
            )

    outdir = None
    if outroot is not None and save_csv:
        outdir = os.path.abspath(outroot)
        os.makedirs(outdir, exist_ok=True)
        folds_path = os.path.join(outdir, "ic_walkforward_folds.csv")
        rec_path = os.path.join(outdir, "ic_walkforward_recommendation.json")
        try:
            folds_df.to_csv(folds_path, index=False)
            print(f"[save] folds → {folds_path}")
        except Exception as e:
            print(f"[save] folds failed: {e}")
        try:
            with open(rec_path, "w") as f:
                json.dump(recommendation, f, indent=2)
            print(f"[save] recommendation → {rec_path}")
        except Exception as e:
            print(f"[save] recommendation failed: {e}")

    return {"folds": folds_df, "recommendation": recommendation, "outdir": outdir}


# ============================== benchmark ================================

def _benchmetrics_from_price(price_series: pd.Series) -> Dict[str, float]:
    """
    Turn a close series into a NAV-like equity (base=100) and reuse _equity_to_metrics.
    """
    if price_series is None or len(price_series) == 0:
        return dict(CAGR=np.nan, Sharpe=np.nan, MaxDD=np.nan, Vol=np.nan)
    s = pd.Series(price_series.astype(float).values, index=pd.to_datetime(price_series.index))
    nav = (s / float(s.iloc[0])) * 100.0
    return _equity_to_metrics(pd.Series(nav.values, index=nav.index, name="equity"))


def _eqw_close_series(tickers: List[str], start: str, end: str) -> pd.Series:
    """
    Build an equal-weight close-price series over [start, end] (inclusive),
    per ticker. Robust to single-level and MultiIndex OHLC frames.
    """

    def _close_series_from_df(df: pd.DataFrame) -> Optional[pd.Series]:
        """Return a 1D close-like Series or None."""
        if df is None or df.empty:
            return None

        # 1) Direct single-level hits
        for name in ("Close", "Adj Close", "close", "adjclose", "AdjClose"):
            if name in df.columns:
                col = df[name]
                if isinstance(col, pd.Series):
                    return pd.to_numeric(col, errors="coerce")
                elif isinstance(col, pd.DataFrame):
                    # Take the first column if yfinance gave a slice
                    if col.shape[1] >= 1:
                        return pd.to_numeric(col.iloc[:, 0], errors="coerce")

        # 2) MultiIndex last-level hits
        if isinstance(df.columns, pd.MultiIndex):
            for key in ("Close", "Adj Close", "close", "adjclose"):
                try:
                    # keep remaining levels so we can select a single column below
                    sli = df.xs(key, axis=1, level=-1, drop_level=False)
                    if isinstance(sli, pd.Series):
                        return pd.to_numeric(sli, errors="coerce")
                    if isinstance(sli, pd.DataFrame) and sli.shape[1] >= 1:
                        return pd.to_numeric(sli.iloc[:, 0], errors="coerce")
                except Exception:
                    pass

            # 3) Any tuple whose parts look close-like
            for col in df.columns:
                try:
                    parts = (col if isinstance(col, tuple) else (col,))
                    if any(str(p).lower() in ("close", "adj close", "adjclose") for p in parts):
                        ser = df[col]
                        if isinstance(ser, pd.Series):
                            return pd.to_numeric(ser, errors="coerce")
                except Exception:
                    pass

        # 4) Last resort: pick the first numeric-looking column
        for c in df.columns:
            ser = df[c]
            if isinstance(ser, pd.Series) and pd.api.types.is_numeric_dtype(ser):
                return pd.to_numeric(ser, errors="coerce")

        return None

    closes = []
    start_str = str(start)
    end_str   = str(end)
    end_plus1 = (pd.to_datetime(end_str) + pd.Timedelta(days=1)).strftime("%Y-%m-%d")

    for t in tickers:
        df = fetch_ohlc_yf(t, start_str, end_str)
        if df is None or df.empty:
            df = fetch_ohlc_yf(t, start_str, end_plus1)

        if df is None or df.empty:
            print(f"[bench] {t}: no OHLC in {start_str}→{end_str} (even with +1d).")
            continue

        s = _close_series_from_df(df)
        if s is None:
            print(f"[bench] {t}: found OHLC but no usable Close/Adj Close.")
            continue

        s = s.dropna()
        if s.empty:
            print(f"[bench] {t}: close series empty after dropna.")
            continue

        s.index = pd.to_datetime(s.index)
        mask = (s.index >= pd.to_datetime(start_str)) & (s.index <= pd.to_datetime(end_str))
        s = s.loc[mask]
        if s.empty:
            print(f"[bench] {t}: no dates within {start_str}→{end_str}.")
            continue

        closes.append(s.rename(t))

    if not closes:
        print(f"[bench] EQW: no usable price series for {tickers} in {start_str}→{end_str}.")
        return pd.Series(dtype=float)

    panel = pd.concat(closes, axis=1).sort_index().ffill()
    eq = panel.mean(axis=1, skipna=True)
    eq.name = "EQW"
    return eq


def benchmark_compare_eqw(folds: pd.DataFrame, tickers: List[str], outdir: Optional[str]) -> pd.DataFrame:
    """
    Compare OOS folds against equal-weight buy&hold of *your tickers*.
    Returns a DataFrame and saves <outdir>/ic_benchmark_compare_eqw.csv
    """
    if folds is None or folds.empty:
        return pd.DataFrame()

    rows: List[Dict[str, Any]] = []
    for _, r in folds.iterrows():
        s_fold = str(r["fold_start"])
        e_fold = str(r["fold_end"])
        bench = _eqw_close_series(list(tickers), s_fold, e_fold)

        # Strategy metrics (already normalized); suppress noisy CAGR for short windows here as well
        sm = dict(
            Sharpe=float(r.get("Sharpe", np.nan)),
            CAGR=float(r.get("CAGR", np.nan)),
            MaxDD=float(r.get("MaxDD", np.nan)),
            Vol=float(r.get("Vol", np.nan)),
        )
        # suppress strategy CAGR if window is short
        try:
            days = (pd.to_datetime(e_fold) - pd.to_datetime(s_fold)).days
            if days < 120:
                sm["CAGR"] = np.nan
        except Exception:
            pass

        n_tr = None
        try:
            n_tr = int(r.get("n_trades")) if pd.notna(r.get("n_trades")) else None
        except Exception:
            n_tr = None

        if bench.empty or bench.dropna().shape[0] < 5:
            print(f"[bench] empty EQW series for {tickers} in {s_fold}→{e_fold}; skipping benchmark metrics.")
            rows.append(dict(
                fold_start=s_fold, fold_end=e_fold,
                strat_Sharpe=sm["Sharpe"], strat_CAGR=sm["CAGR"], strat_MaxDD=sm["MaxDD"], strat_Vol=sm["Vol"],
                bench_Sharpe=np.nan, bench_CAGR=np.nan, bench_MaxDD=np.nan, bench_Vol=np.nan,
                n_trades=n_tr,
                dSharpe=np.nan, dCAGR=np.nan, dMaxDD=np.nan, dVol=np.nan
            ))
            continue

        bm = _benchmetrics_from_price(bench)

        dSharpe = (sm["Sharpe"] - bm["Sharpe"]) if (np.isfinite(sm["Sharpe"]) and np.isfinite(bm["Sharpe"])) else np.nan
        dCAGR   = (sm["CAGR"]   - bm["CAGR"])   if (np.isfinite(sm["CAGR"])   and np.isfinite(bm["CAGR"]))   else np.nan
        # dMaxDD: bench minus strat (positive => strategy shallower)
        dMaxDD  = (bm["MaxDD"]  - sm["MaxDD"])  if (np.isfinite(sm["MaxDD"])  and np.isfinite(bm["MaxDD"]))  else np.nan
        dVol    = (sm["Vol"]    - bm["Vol"])    if (np.isfinite(sm["Vol"])    and np.isfinite(bm["Vol"]))    else np.nan

        rows.append(dict(
            fold_start=s_fold, fold_end=e_fold,
            strat_Sharpe=sm["Sharpe"], strat_CAGR=sm["CAGR"], strat_MaxDD=sm["MaxDD"], strat_Vol=sm["Vol"],
            bench_Sharpe=bm["Sharpe"], bench_CAGR=bm["CAGR"], bench_MaxDD=bm["MaxDD"], bench_Vol=bm["Vol"],
            n_trades=n_tr,
            dSharpe=dSharpe, dCAGR=dCAGR, dMaxDD=dMaxDD, dVol=dVol
        ))

    comp = pd.DataFrame(rows)
    if outdir:
        path = os.path.join(outdir, "ic_benchmark_compare_eqw.csv")
        try:
            comp.to_csv(path, index=False)
            print(f"[save] benchmark compare (equal-weight) → {path}")
        except Exception as e:
            print(f"[save] benchmark compare failed: {e}")
    return comp



# ============================== public API ===============================

def run_optimize(
    tickers: List[str],
    start: str,
    end: str,
    dtes: Iterable[int],
    wings: Iterable[float],
    ptails: Iterable[float],
    edges: Iterable[float],
    train_years: int,
    test_months: int,
    outroot: str = "data/opt",
    *,
    min_trades_train: int = 10,
) -> Dict[str, Any]:
    return walkforward_optimize(
        tickers=tickers,
        start=start,
        end=end,
        dtes=list(dtes),
        wings=list(wings),
        ptails=list(ptails),
        edges=list(edges),
        train_years=train_years,
        test_months=test_months,
        outroot=outroot,
        save_csv=True,
        min_trades_train=min_trades_train,
    )


# ================================= CLI ==================================

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--start", required=True)
    ap.add_argument("--end", required=True)
    ap.add_argument("--tickers", nargs="+", required=True)
    ap.add_argument("--dtes",   nargs="+", type=int,   default=[7,14,21,28,35,45])
    ap.add_argument("--wings",  nargs="+", type=float, default=[2,3,5,7,10])
    ap.add_argument("--ptails", nargs="+", type=float, default=[0.10,0.15,0.20,0.25,0.30])
    ap.add_argument("--edges",  nargs="+", type=float, default=[-2.5,0,2.5,5,7.5,10])
    ap.add_argument("--train_years", type=int, default=2)
    ap.add_argument("--test_months", type=int, default=3)
    ap.add_argument("--outroot", default="data/opt")
    ap.add_argument("--min_trades", type=int, default=-1,
                    help="override train min-trades; default auto (5 for 1 ticker, else 10)")
    args = ap.parse_args()

    # Adaptive MIN_TRADES for single-ticker runs (unless user overrides)
    auto_min_trades = (5 if len(args.tickers) <= 1 else 10)
    min_trades_train = auto_min_trades if args.min_trades < 0 else int(args.min_trades)
    print(f"[setup] tickers={len(args.tickers)} min_trades_train={min_trades_train} range={args.start}→{args.end}")


    res = run_optimize(
        args.tickers, args.start, args.end,
        args.dtes, args.wings, args.ptails, args.edges,
        args.train_years, args.test_months, args.outroot,
        min_trades_train=min_trades_train,
    )

    folds = res["folds"].copy()
    rec = res["recommendation"]

    # suppress noisy CAGR for short OOS windows (<120 days) only for printing
    if isinstance(folds, pd.DataFrame) and not folds.empty:
        _d1 = pd.to_datetime(folds["fold_start"])
        _d2 = pd.to_datetime(folds["fold_end"])
        days = (_d2 - _d1).dt.days
        folds_print = folds.copy()
        folds_print.loc[days < 120, "CAGR"] = np.nan
    else:
        folds_print = folds

    print("\n=== Walk-forward OOS (portfolio) ===")
    if isinstance(folds_print, pd.DataFrame) and not folds_print.empty:
        cols = ["fold_start","fold_end","dte","wing","p_tail","edge_min",
                "Sharpe","CAGR","MaxDD","Vol","n_trades","error"]
        print(folds_print[cols].to_string(index=False))
    else:
        print("(no folds)")

    print("\n=== Recommended params (portfolio) ===")
    print(json.dumps(rec, indent=2))

    # Equal-weight benchmark comparison (your tickers)
    comp = benchmark_compare_eqw(folds, args.tickers, res.get("outdir"))
    show_cols = ["fold_start","fold_end",
                 "strat_Sharpe","bench_Sharpe",
                 "strat_CAGR","bench_CAGR",
                 "strat_MaxDD","bench_MaxDD",
                 "strat_Vol","bench_Vol",
                 "n_trades","dSharpe","dCAGR","dMaxDD","dVol"]
    print("\n=== OOS vs Equal-Weight Buy&Hold (your tickers) ===")
    if not comp.empty:
        # keep display tidy if columns missing for any reason
        cols = [c for c in show_cols if c in comp.columns]
        print(comp[cols].to_string(index=False))
    else:
        print("(no folds to compare)")


if __name__ == "__main__":
    main()
