# scripts/walkforward.py
from __future__ import annotations
import argparse, datetime as dt, subprocess

def _quarter_end(y: int, m: int) -> dt.date:
    q_end_month = ((m - 1) // 3) * 3 + 3
    # last day of that month
    if q_end_month in (1, 3, 5, 7, 8, 10, 12):
        last_day = 31
    elif q_end_month == 2:
        last_day = 29 if (y % 400 == 0 or (y % 4 == 0 and y % 100 != 0)) else 28
    else:
        last_day = 30
    return dt.date(y, q_end_month, last_day)

def _daterange_qtr(start: dt.date, end: dt.date):
    """
    Yield (quarter_start_iso, quarter_end_iso) windows.
    Start is pinned to the beginning of its quarter.
    End is the FULL quarter end (not truncated to 'end'), and
    we stop once the quarter start passes 'end'.
    """
    q_start = dt.date(start.year, ((start.month - 1) // 3) * 3 + 1, 1)
    while q_start <= end:
        q_end = _quarter_end(q_start.year, q_start.month)
        yield q_start.isoformat(), q_end.isoformat()
        # next quarter start
        if q_end.month == 12:
            q_start = dt.date(q_start.year + 1, 1, 1)
        else:
            q_start = dt.date(q_start.year, q_end.month + 1, 1)

def main():
    ap = argparse.ArgumentParser("Generate (and optionally run) quarterly backtests")
    ap.add_argument("--start", required=True)   # YYYY-MM-DD
    ap.add_argument("--end", required=True)     # YYYY-MM-DD
    ap.add_argument("--strategy", default="both", choices=["condor","debit","both"])
    ap.add_argument("--tickers", default="AAPL,MSFT,SPY", help="Comma-separated tickers")
    ap.add_argument("--dte", type=int, default=21)
    ap.add_argument("--step", type=int, default=5)
    ap.add_argument("--p_tail", type=float, default=0.20)
    ap.add_argument("--wing", type=float, default=5.0)
    ap.add_argument("--save_trades", action="store_true")
    ap.add_argument("--execute", action="store_true", help="Actually run the commands")
    args = ap.parse_args()

    s = dt.date.fromisoformat(args.start)
    e = dt.date.fromisoformat(args.end)

    # Convert CSV to **space-separated** list for the runner
    tickers_spaced = " ".join(t.strip() for t in args.tickers.replace(";", ",").split(",") if t.strip())

    cmds = []
    for qs, qe in _daterange_qtr(s, e):
        cmd = (
            "python -m scripts.run_backtest_yf "
            f"--start {qs} --end {qe} --strategy {args.strategy} "
            f"--tickers {tickers_spaced} --step {args.step} --dte {args.dte} "
            f"--p_tail {args.p_tail} --wing {args.wing}"
            + (" --save_trades" if args.save_trades else "")
        )
        cmds.append(cmd)

    for c in cmds:
        print(c)

    if args.execute:
        for c in cmds:
            print(f"\n>>> {c}")
            subprocess.check_call(c, shell=True)

if __name__ == "__main__":
    main()
