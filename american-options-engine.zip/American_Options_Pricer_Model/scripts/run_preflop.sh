#!/usr/bin/env bash
set -euo pipefail
export AOE_LEDGER="${AOE_LEDGER:-data/pnl_paper.csv}"

mkdir -p logs
# Ensure ledger exists ahead of time (even if no trades fire today)
python -c "from aoe.pnl.ledger import ensure_ledger_exists; p=ensure_ledger_exists(); print(f'[init-ledger] ensured {p}')" | tee -a logs/preflop.log

echo "[$(date -u +'%FT%TZ')] screen_day starting (AOE_LEDGER=$AOE_LEDGER)" | tee -a logs/preflop.log
python -m scripts.screen_day >> logs/preflop.log 2>&1 || {
  echo "[$(date -u +'%FT%TZ')] screen_day failed" | tee -a logs/preflop.log
  exit 1
}
echo "[$(date -u +'%FT%TZ')] screen_day finished" | tee -a logs/preflop.log
