#!/usr/bin/env python
"""
Daily “pre-flop” options screener.

Workflow
--------
1) Rank blue-chips (aoe.universe.select.score_universe).
2) For each top-N ticker:
      • ensure calibrated model (scripts.calibrate.ensure_model)
      • load latest fresh model JSON from data/models
      • scan single legs, build debit spreads
      • price fair value, compute edge%, Kelly size
      • place orders into CSV ledger via broker
3) Print a one-page summary.
"""

from __future__ import annotations

import datetime as dt
import json
import math
import pathlib
import subprocess
import sys
from typing import Optional

import pandas as pd

from aoe.signals.macro import sigma_multiplier
from aoe.universe.select import score_universe
from aoe.data.chain import scan_high_ev_contracts
from aoe.strategy.spreads import build_range_spreads
from aoe.pricing.spread import price_debit_spread
from aoe.risk.sizer import kelly_size
from aoe.execution.broker import execute_order
from scripts.calibrate import ensure_model

# ---------------------------------------------------------------------------#
# parameters
# ---------------------------------------------------------------------------#

EDGE_THRES = 0.10          # 10 % fair-value edge required
BANKROLL = 50_000          # $ capital
TOP_N = 6                  # tickers to scan each day
MAX_TRADE_PCT = 0.05       # bankroll fraction per trade

MODEL_DIR = pathlib.Path("data/models")
MODEL_DIR.mkdir(parents=True, exist_ok=True)

# ---------------------------------------------------------------------------#
# helpers
# ---------------------------------------------------------------------------#


def _find_latest_model_path(ticker: str) -> Optional[pathlib.Path]:
    tk = ticker.upper()
    candidates = sorted(MODEL_DIR.glob(f"{tk}_*.json"))
    if not candidates:
        return None

    def _score(p: pathlib.Path):
        # Prefer filename date when present, fall back to mtime
        try:
            date_str = p.stem.split("_", 1)[1]
            d = dt.datetime.strptime(date_str, "%Y%m%d").date()
        except Exception:
            d = dt.date.min
        return (d, p.stat().st_mtime)

    return max(candidates, key=_score)


def load_model(ticker: str, spot: float | None = None, max_age_days: int = 5) -> dict:
    """
    Load a calibrated model JSON for `ticker` from data/models/{TICKER_YYYYMMDD}.json.
    If missing or stale (>max_age_days), auto-calibrate via `python -m scripts.calibrate TICKER`.
    Returns the parsed model dict.
    """
    def _is_fresh(p: pathlib.Path) -> bool:
        try:
            with p.open() as f:
                m = json.load(f)
            d = dt.datetime.strptime(m.get("date"), "%Y-%m-%d").date()
            return (dt.date.today() - d).days <= max_age_days
        except Exception:
            return False

    path = _find_latest_model_path(ticker)
    if path is None or not _is_fresh(path):
        # calibrate on miss/stale
        cmd = [sys.executable, "-m", "scripts.calibrate", ticker.upper()]
        print(f"[MODEL] calibrating {ticker} → {' '.join(cmd)}")
        subprocess.check_call(cmd)
        path = _find_latest_model_path(ticker)
        if path is None:
            raise FileNotFoundError(
                f"[MODEL] after calibration, no model file found for {ticker} in {MODEL_DIR}"
            )

    with path.open() as f:
        model = json.load(f)

    if "params" not in model or "snapshot" not in model:
        raise ValueError(f"[MODEL] malformed model JSON at {path}")

    print(f"[MODEL] loaded {ticker}: date={model.get('date')} rms={model.get('rms')} ← {path}")
    return model


def _spot_from_model(model: dict, fallback: Optional[float]) -> float:
    if fallback is not None and not math.isnan(fallback):
        return float(fallback)
    try:
        return float(model["snapshot"]["spot"])
    except Exception:
        raise ValueError("No spot available (neither fallback nor snapshot.spot).")


# ---------------------------------------------------------------------------#
# main
# ---------------------------------------------------------------------------#


def screen_day() -> None:
    today = dt.date.today()
    print(f"\n=== {today.isoformat()} Pre-flop Screener ===")

    picks: list[dict] = []

    # 1) rank universe
    uni = score_universe(TOP_N)

    for _, row in uni.iterrows():
        tk = row["ticker"]

        # Ensure a reasonably fresh model exists (side-effect)
        try:
            snap = ensure_model(tk)  # some variants return a snapshot dict
            spot_hint = (snap or {}).get("spot") if isinstance(snap, dict) else None
        except Exception:
            # tolerate ensure_model variants; load_model will calibrate if needed
            spot_hint = None

        # IMPORTANT: call positionally so tests can monkeypatch with (tk, s)
        model = load_model(tk, spot_hint)

        # ---- macro vol boost (info only) -----------------------------------
        mult = sigma_multiplier(today)
        if mult > 1.0:
            print(f"  {tk}: macro vol boost {mult:.2f}×")

        # ---- scan chain & build spreads ------------------------------------
        singles = scan_high_ev_contracts(tk)
        spreads = build_range_spreads(singles, model)
        if spreads.empty:
            continue

        # ---- evaluate each spread ------------------------------------------
        spot = _spot_from_model(model, spot_hint)

        for _, sp in spreads.iterrows():
            expiry = pd.to_datetime(sp.expiry).date() if not isinstance(sp.expiry, dt.date) else sp.expiry
            t_years = max(1e-6, (expiry - today).days / 365.0)

            model_px = price_debit_spread(
                model,
                spot,
                sp.long_k,
                sp.short_k,
                r=0.02,
                q=0.0,
                t=t_years,
                option_type="call" if sp.right == "C" else "put",
            )

            mid = float(sp.net_mid)
            edge_pct = (model_px - mid) / mid if mid != 0 else -1.0
            if edge_pct < EDGE_THRES:
                continue

            qty = int(kelly_size(edge_pct, sp.max_loss, BANKROLL, cap=MAX_TRADE_PCT))
            if qty < 1:
                continue

            order = {
                "ticker": tk,
                "expiry": expiry.isoformat(),
                "right": sp.right,
                "long_k": float(sp.long_k),
                "short_k": float(sp.short_k),
                "qty": qty,
                "price": mid,
            }
            execute_order(order)
            picks.append({**order, "edge%": round(edge_pct * 100, 1)})

    # ---- summary -----------------------------------------------------------
    if picks:
        print("\nFilled orders:")
        print(pd.DataFrame(picks).to_string(index=False))
    else:
        print("No spreads met the edge threshold today.")


# ---------------------------------------------------------------------------#
# CLI entry-point
# ---------------------------------------------------------------------------#

def main() -> None:
    """Optional positional tickers: `python -m scripts.screen_day AAPL MSFT`."""
    tickers = sys.argv[1:]
    if tickers:
        T = [t.strip().upper() for t in tickers if t.strip()]

        # Override the scorer to use the user-specified list exactly
        def _score_universe(_n):  # type: ignore
            return pd.DataFrame({"ticker": T})
        # replace imported function reference
        globals()["score_universe"] = _score_universe

        # update module-global cap inside a function
        global TOP_N  # noqa: PLW0603
        TOP_N = len(T)

    screen_day()


if __name__ == "__main__":
    main()

