#!/usr/bin/env python
"""
Calibrate Heston parameters for one or more tickers and save to JSON.

Output schema (per file):
{
  "ticker":   "AAPL",
  "date":     "2025-07-25",
  "params":   {"kappa":..., "theta":..., "sigma":..., "rho":..., "v0":...},
  "rms":      0.1234,
  "snapshot": {
      "spot": 187.32,
      "earnings": "2025-08-13" | null,
      "iv_surface": {
          "index":   [... year-fractions ...],
          "columns": [... strikes ...],
          "data":    [[... ivs ...]]
      }
  }
}

Usage:
    python -m scripts.calibrate  AAPL MSFT SPY
"""

import json
import pathlib
import datetime as dt

import pandas as pd

from aoe.data.yf import get_snapshot
from aoe.models.heston_calibration import calibrate_heston
from aoe.models.heston import HestonModel  # noqa: F401 (needed by downstream code)

# where JSON files go
OUT_DIR = pathlib.Path("data/models")
OUT_DIR.mkdir(parents=True, exist_ok=True)


# ---------------------------------------------------------------------
# Helpers to make snapshot JSON-safe and to restore it
# ---------------------------------------------------------------------
def _make_json_safe_snapshot(snap: dict) -> dict:
    """Convert snapshot dict to JSON-serializable form (no DataFrames, no dates)."""
    ivdf: pd.DataFrame = snap["iv_surface"]
    return {
        "spot": float(snap["spot"]),
        "earnings": snap["earnings"].isoformat() if snap["earnings"] else None,
        "iv_surface": {
            "index":   ivdf.index.tolist(),
            "columns": ivdf.columns.tolist(),
            "data":    ivdf.values.tolist(),
        },
    }


def _restore_snapshot(jsnap: dict) -> dict:
    """Convert JSON-safe snapshot back into original structure (with DataFrame)."""
    iv_info = jsnap["iv_surface"]
    iv_df = pd.DataFrame(iv_info["data"], index=iv_info["index"], columns=iv_info["columns"])
    earnings = (
        dt.date.fromisoformat(jsnap["earnings"]) if jsnap.get("earnings") else None
    )
    return {
        "spot": jsnap["spot"],
        "earnings": earnings,
        "iv_surface": iv_df,
    }


# ---------------------------------------------------------------------
# Core calibration routine
# ---------------------------------------------------------------------
def calibrate_ticker(ticker: str) -> dict:
    """Run calibration for a single ticker, return dict that was saved."""
    snap = get_snapshot(ticker)  # may raise; caller handles
    spot = snap["spot"]

    # Prepare surface
    iv_df = snap["iv_surface"]
    maturities = iv_df.index.to_numpy()
    strikes    = iv_df.columns.to_numpy()
    iv_mat     = iv_df.to_numpy()

    params, rms = calibrate_heston(
        s0=spot,
        r=0.02,         # risk-free guess for calibration
        q=0.0,
        strikes=strikes,
        maturities=maturities,
        iv_matrix=iv_mat,
        start=(1.5, 0.04, 0.3, -0.5, 0.04),
    )

    # Write params both nested and flattened for backward-compatibility
    params_dict = {
        "kappa": float(params[0]),
        "theta": float(params[1]),
        "sigma": float(params[2]),
        "rho":   float(params[3]),
        "v0":    float(params[4]),
    }

    data = {
        "ticker": ticker,
        "date": dt.date.today().isoformat(),
        "params": params_dict,          # nested
        "rms": float(rms),
        **params_dict,                  # flattened keys for old tests/code
        "snapshot": _make_json_safe_snapshot(snap),
    }

    out_file = OUT_DIR / f"{ticker}_{dt.date.today():%Y%m%d}.json"
    with out_file.open("w") as f:
        json.dump(data, f, indent=2)

    print(f"[OK] {ticker}: rms={rms:.4f}  → {out_file}")
    return data


def ensure_model(ticker: str, max_age_days: int = 5):
    """
    Ensure we have a reasonably recent calibration file for `ticker`.
    Returns the *restored* snapshot dict (with DataFrame).
    """
    files = sorted(OUT_DIR.glob(f"{ticker}_*.json"))
    if files:
        latest = files[-1]
        try:
            with latest.open() as f:
                data = json.load(f)
            file_date = dt.date.fromisoformat(data["date"])
            if (dt.date.today() - file_date).days <= max_age_days and "snapshot" in data:
                return _restore_snapshot(data["snapshot"])
        except Exception:
            pass  # fall-through to re-calibrate

    # re-calibrate if missing/old/bad
    data = calibrate_ticker(ticker)
    return _restore_snapshot(data["snapshot"])


# ---------------------------------------------------------------------
def main():
    import sys
    tickers = [tk.upper() for tk in sys.argv[1:]]
    if not tickers:
        print("Usage: python -m scripts.calibrate TICKER [TICKER...]")
        sys.exit(1)
    for tk in tickers:
        try:
            calibrate_ticker(tk)
        except Exception as e:
            print(f"[FAIL] {tk}: {e}")


if __name__ == "__main__":
    main()
